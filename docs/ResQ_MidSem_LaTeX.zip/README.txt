# ResQ Mid-Semester Report — LaTeX

## Files
- `main.tex` — complete report source
- `images/use_case.png`
- `images/class_diagram.png`
- `images/sequence_diagram.png`
- `images/activity_diagram.png`

## Compile
Run:

    pdflatex main.tex
    pdflatex main.tex

The second run is useful if you later change the contents/page references.

The report intentionally uses manual page breaks to mirror the supplied 12-page DOCX layout and avoid accidental blank pages.
